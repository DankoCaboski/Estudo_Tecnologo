/*8 – Faça o teste de mesa para todos os programas implementados. */
public class Ex8 {
}
