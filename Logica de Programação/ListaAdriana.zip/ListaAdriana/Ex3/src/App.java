public class App {
    /*Modele e implemente uma classe Polígono com três atributos e três métodos. Em seguida, 
     *implemente uma outra classe que contenha o método main e nele haja dois objetos da classe 
     *Poligono.
    */
    public static void main(String[] args) throws Exception {
        Poligono cubo = new Poligono();
        Poligono paralelepipeo = new Poligono();
    }
}
